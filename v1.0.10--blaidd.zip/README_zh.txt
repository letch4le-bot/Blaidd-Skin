blaidd v1.0.10

布莱泽和仿生泪滴在关卡强泛光下保留更多原本的颜色。
仿生泪滴的追逐、剧情、望远镜和 Boss 形态都适用。Boss 的月牙、光屑和攻击特效照常显示。
抚胸望月的月盘保留完整底弧。

需要 Everest 1.6642.0 和 Skin Mod Helper Plus 0.17.13 或更高版本。
退出游戏，把旧版布莱泽 ZIP 及独立的 BlaiddBloomPreview 补丁（如果装过）移出 Mods。
将本 ZIP 放进 Mods 后重新启动，无需解压。
